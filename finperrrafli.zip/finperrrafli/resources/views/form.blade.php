<!-- resources/views/dashboard-form.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Input Mitra ID</title>
</head>
<body>
    <form action="{{ url('/dashboard-mitra') }}" method="get">
        <label for="mitraID">Mitra ID:</label>
        <input type="text" id="mitraID" name="mitraID">
        <button type="submit">Submit</button>
    </form>
</body>
</html>
