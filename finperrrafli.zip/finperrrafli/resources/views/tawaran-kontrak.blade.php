<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter&family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', 'sans-serif';
            background-color: #8DA9BF;
        }

        .navbar {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #135589;
            color: #fff;
            box-shadow: 0px 4px 7px rgba(0, 0, 0, 0.47);
        }

        .navbar-logo {
            margin-right: auto;
        }

        .navbar-logo img {
            width: 30px
        }

        .navbar-icon {
            display: flex;
            align-items: center;
        }

        .navbar-icon-2 img {
            width: 35px;
            margin: 0 10px;
        }

        .button-container {
            display: flex;
            justify-content: right;
            margin-top: 20px;
        }

        .jumbotron {
            background-color: #242424;
            border-radius: 0px 20px 0px 0px;
        }

        .btn-dark {
            background-color: #242424;
            font-color: white;
            margin-top: 50px;
            padding: 15px;
            border-radius: 20px 20px 0px 0px;
        }

        .grid-container {
            display: grid;
            grid-template-columns: 1fr 11fr;
            margin-right: 70px;
        }

        #setuju-btn {
            background-color: white;
            color: #135589;
            border-radius: 100px;
            width: 80px;
            height: 40px;
        }

        #tolak-btn {
            background-color: #135589;
            color: white;
            border-radius: 100px;
            width: 80px;
            height: 40px;
            margin-left: 20px;
        }

        #ya-btn {
            background-color: #135589;
            color: white;
            border-radius: 30px;
            width: 70px;
            height: 40px;
            font-size: 12px
        }

        #tidak-btn {
            background-color: white;
            color: #135589;
            border-radius: 30px;
            width: 70px;
            height: 40px;
            margin-left: 20px;
            font-size: 12px
        }
    </style>

</head>

<body>
    <nav class="navbar">
        <div class="navbar-logo">
            <a href="#">
                <img src="images/logo-finper.png" alt="Logo">
            </a>
        </div>
        <div class="navbar-icon-2">
            <a href="#">
                <img src="images/icon-pp-mitra.png" alt="Profile">
            </a>
        </div>
    </nav>
    <div class="grid-container">
        <div class="column-1">
            <a href="/dashboard-mitra">
                <img src="images/icon-back.png" alt="back" style="width:30%; margin-left:50px; margin-top:70px">
            </a>
        </div>
        <div class="column-2">
            <div class="container">
                <button type="button" class="btn btn-dark">Tawaran Kontrak</button>
                <div class="jumbotron">
                    <div class="container" style="width:70%; margin-bottom:20px">
                        @foreach ($tawaranKontrak as $t)
                            <table id="tabelData_{{ $t->kontrakID }}" class="table table-bordered" cellpadding="5"
                                cellspacing="0"
                                style="border-collapse: collapse; text-align: center; margin: 0 auto; flex-basis:50%">
                                <tr style="background-color: #E2E2E2; color: black; font-weight: bold;">
                                    <td><b>Nama</b></td>
                                    <td><b>Lokasi</b></td>
                                    <td><b>Hari Kerja</b></td>
                                    <td><b>Jam Kerja</b></td>
                                </tr>
                                <tr style="background-color: #FFFFFF; color: black;">
                                    <td>{{ $t->nama_pelanggan }}</td>
                                    <td>{{ $t->lokasi_pelanggan }}</td>
                                    <td>{{ $t->hariKerja }}</td>
                                    <td>{{ $t->jamKerja }}</td>
                                </tr>
                                <tr style="background-color: #135589; color: white; text-align: left;">
                                    <td colspan="3" style="text-align: left;">Total Harga</td>
                                    <td>{{ $t->totalPembayaran }}</td>
                                </tr>
                            </table>
                            {{-- <button form="setuju-form" type="submit">Setuju</button>
                            <button form="tolak-form" type="submit">Tolak</button> --}}

                            <div class="button-container" style="margin-bottom:20px">
                                <button id="setuju-btn" type="button" class="btn btn-primary btn-sm"
                                    data-toggle="modal" data-target="#setujuModal"
                                    data-kontrakid="{{ $t->kontrakID }}"><b>Setuju</b></button>

                                <button id="tolak-btn" type="button" data-toggle="modal" data-target="#tolakModal"
                                    class="btn btn-primary btn-sm"><b>Tolak</b></button>

                                <div class="modal fade" id="setujuModal">
                                    <div class="modal-dialog modal-dialog-centered modal-sm">
                                        <div class="modal-content" style="justify-content: center; align-items: center">
                                            <div class="modal-body">
                                                <img src="images/icon-check.png" alt="Alert"
                                                    style="margin-top:20px; margin-left: 60px; width:40%">
                                            </div>
                                            <p style="font-size:15px; text-align:center; margin-bottom:30px"><b>Tawaran
                                                    Diterima</b></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="modal fade" id="tolakModal">
                                    <div class="modal-dialog modal-dialog-centered modal-sm">
                                        <div class="modal-content" style="justify-content:center; align-items:center">
                                            <div class="modal-body">
                                                <img src="images/icon-danger.png" alt="Alert"
                                                    style="margin-left: 40px; width:40%">
                                            </div>
                                            <p style="font-size:14px; text-align:center">Apakah anda yakin<br>ingin
                                                menolak
                                                kontrak
                                                ?</p>
                                            <div class="modal-footer">

                                                <form action="/tawaran-kontrak/tolak/{{ $t->kontrakID }}"
                                                    method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button id="ya-btn" type="submit" class="btn btn-primary btn-sm"
                                                        data-toggle="modal" data-target="#yaModal"><b>Ya</b></button>
                                                </form>

                                                <button id="tidak-btn" type="button" class="btn btn-primary btn-sm"
                                                    data-dismiss="modal"><b>Tidak</b></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
