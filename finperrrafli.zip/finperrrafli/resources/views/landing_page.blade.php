<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<style>
  .fullscreen-img {
    position: absolute;
    left: -1px;
top: 2450px;
    width: 100%;
    height: 100%;
  }
  .fullscreen-img2 {
    position: absolute;
    left: -1px;
top: 3400px;
    width: 100%;
    height: 100%;
  }
  .fullscreen-img3 {
    position: absolute;
    left: -1px;
top: 4350px;
    width: 100%;
    height: 100%;
  }
  .fullscreen-img4 {
    position: absolute;
    left: -1px;
top: 1500px;
    width: 100%;
    height: 100%;
  }
  </style>
<body>

    {{-- nav --}}
    {{-- <form action=" " method="post">
        @csrf --}}

        {{-- <body className='snippet-body'> --}}
            <nav class="navbar navbar-inverse">
                <div class="navbar-logo">
                    <a href="/">
                        <img src="{{ ('img/logo_finper.png') }}" alt="Logo">
                    </a>
                    {{-- <div>
      <a href="/login">Bergabung</a>
    </div> --}}
                </div>
            </nav>
    {{-- </form> --}}

    {{-- Coding sini yod --}}
    {{-- kalau misal sudah masuk ke halaman login, kalau di klik logo di atas baliknya akan terus ke halaman login, kalau mau ke landing page, copas ini http://127.0.0.1:8000 --}}
    <div>
      <a href="/login">Bergabung</a>
    </div>


    <div class="container-fludi">
    <ul class="nav justify-content-center">
 <dl>
    <h2>Platform Penyedia Jasa</h2>
    <h2>Pekerja Rumah Tangga</h2>
    <h2>#Di Indonesia</h2>
  </dl>
         <img src="img/avatar1.jpg" class="" alt="" width="full" height="auto">
</div>
      </div>
    </div>
    <div>
  <!-- <div class="bg-primary">
            <div class="container my-2">
              <div class=" nav justify-content-center">
    <div class="row my-4">
      <div class="col-sm bg-light rounded-sm"><svg width="310" height="300" viewBox="0 -12 248 328" fill="none" xmlns="http://www.w3.org/2000/svg">
<g filter="url(#filter0_d_2531_10865)">
<rect x="4" y="41" width="233" height="275.598" rx="40" fill="#D9D9D9"/>
</g>
<path d="M174.95 129.15H66.05C62.7093 129.15 60 131.859 60 135.2V207.8C60 211.141 62.7093 213.85 66.05 213.85H174.95C178.291 213.85 181 211.141 181 207.8V135.2C181 131.859 178.291 129.15 174.95 129.15ZM93.275 185.09V188.137C93.275 188.973 92.5982 189.65 91.7625 189.65H88.7375C87.9018 189.65 87.225 188.973 87.225 188.137V185.058C85.0905 184.948 83.0146 184.203 81.2941 182.912C80.5568 182.358 80.519 181.254 81.1863 180.616L83.4078 178.497C83.9315 177.998 84.7105 177.975 85.323 178.359C86.0547 178.817 86.8847 179.062 87.7468 179.062H93.0614C94.2903 179.062 95.2923 177.943 95.2923 176.569C95.2923 175.444 94.6098 174.453 93.6342 174.162L85.1264 171.61C81.6117 170.555 79.1558 167.182 79.1558 163.406C79.1558 158.77 82.7575 155.004 87.2231 154.885V151.837C87.2231 151.002 87.9 150.325 88.7356 150.325H91.7606C92.5963 150.325 93.2731 151.002 93.2731 151.837V154.917C95.4076 155.027 97.4835 155.77 99.204 157.063C99.9413 157.617 99.9792 158.721 99.3118 159.358L97.0903 161.478C96.5666 161.977 95.7876 162 95.1751 161.616C94.4434 161.156 93.6134 160.912 92.7513 160.912H87.4368C86.2078 160.912 85.2058 162.032 85.2058 163.406C85.2058 164.531 85.8883 165.522 86.8639 165.813L95.3717 168.365C98.8864 169.42 101.342 172.793 101.342 176.569C101.342 181.206 97.7407 184.971 93.275 185.09ZM138.65 182.087C138.65 182.923 137.973 183.6 137.138 183.6H115.963C115.127 183.6 114.45 182.923 114.45 182.087V179.062C114.45 178.227 115.127 177.55 115.963 177.55H137.138C137.973 177.55 138.65 178.227 138.65 179.062V182.087ZM168.9 182.087C168.9 182.923 168.223 183.6 167.388 183.6H152.263C151.427 183.6 150.75 182.923 150.75 182.087V179.062C150.75 178.227 151.427 177.55 152.263 177.55H167.388C168.223 177.55 168.9 178.227 168.9 179.062V182.087ZM168.9 163.937C168.9 164.773 168.223 165.45 167.388 165.45H115.963C115.127 165.45 114.45 164.773 114.45 163.937V160.912C114.45 160.077 115.127 159.4 115.963 159.4H167.388C168.223 159.4 168.9 160.077 168.9 160.912V163.937Z" fill="black" fill-opacity="0.3"/>
<g filter="url(#filter1_d_2531_10865)">
<rect x="4" width="233" height="54" rx="15" fill="#E88A33"/>
</g>
<defs>
<filter id="filter0_d_2531_10865" x="1" y="38" width="247" height="289.598" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dx="4" dy="4"/>
<feGaussianBlur stdDeviation="3.5"/>
<feComposite in2="hardAlpha" operator="out"/>
<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.31 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2531_10865"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2531_10865" result="shape"/>
</filter>
<filter id="filter1_d_2531_10865" x="0" y="0" width="241" height="62" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="4"/>
<feGaussianBlur stdDeviation="2"/>
<feComposite in2="hardAlpha" operator="out"/>
<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2531_10865"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2531_10865" result="shape"/>
</filter>
</defs>
</svg>
<p>Berikan range  gaji  sesuai dengan yang kamu inginkan!</p>
</div>
      <div class="col-sm bg-light rounded-sm"><svg width="310" height="300" viewBox="0 -12 248 328" fill="none" xmlns="http://www.w3.org/2000/svg">
<g filter="url(#filter0_d_2529_10862)">
<rect x="4" y="41" width="233" height="275.598" rx="40" fill="#D9D9D9"/>
</g>
<g filter="url(#filter1_d_2529_10862)">
<rect x="4" width="233" height="54" rx="15" fill="#E88A33"/>
</g>
<path d="M64.9391 212V198.5L86.1391 176.3C88.7391 173.5 90.5724 171.1 91.6391 169.1C92.7724 167.1 93.3391 165.1 93.3391 163.1C93.3391 158.033 90.1057 155.5 83.6391 155.5C80.9724 155.5 78.2391 156 75.4391 157C72.7057 158 69.9724 159.533 67.2391 161.6L61.5391 148.2C64.6057 145.8 68.3057 143.9 72.6391 142.5C77.0391 141.1 81.5724 140.4 86.2391 140.4C94.3724 140.4 100.572 142.167 104.839 145.7C109.172 149.233 111.339 154.333 111.339 161C111.339 165.267 110.372 169.367 108.439 173.3C106.506 177.167 103.272 181.3 98.7391 185.7L87.3391 197.1H113.939V212H64.9391ZM154.7 212V200.2H126.1V187.3L157.6 141.5H172.4V186.3H181.6V200.2H172.4V212H154.7ZM154.7 186.3V167.4L142 186.3H154.7Z" fill="black" fill-opacity="0.3"/>
<defs>
<filter id="filter0_d_2529_10862" x="1" y="38" width="247" height="289.598" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dx="4" dy="4"/>
<feGaussianBlur stdDeviation="3.5"/>
<feComposite in2="hardAlpha" operator="out"/>
<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.31 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2529_10862"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2529_10862" result="shape"/>
</filter>
<filter id="filter1_d_2529_10862" x="0" y="0" width="241" height="62" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="4"/>
<feGaussianBlur stdDeviation="2"/>
<feComposite in2="hardAlpha" operator="out"/>
<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2529_10862"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2529_10862" result="shape"/>
</filter>
</defs>
</svg>
<p>Mencari seorang pekerja rumah tangga dengan spesifikasi  umur tertentu?</p>
 </div>
      <div class="col-sm bg-light"><svg width="310" height="300" viewBox="0 -12 248 328" fill="none" xmlns="http://www.w3.org/2000/svg">
<g filter="url(#filter0_d_2529_10863)">
<rect x="4" y="41" width="233" height="275.598" rx="40" fill="#D9D9D9"/>
</g>
<g filter="url(#filter1_d_2529_10863)">
<rect x="4" width="233" height="54" rx="15" fill="#E88A33"/>
</g>
<g clip-path="url(#clip0_2529_10863)">
<path d="M177.423 219.155L154.833 196.374C153.813 195.346 152.431 194.774 150.981 194.774H147.288C153.541 186.708 157.257 176.564 157.257 165.527C157.257 139.273 136.162 118 110.13 118C84.0975 118 63 139.273 63 165.527C63 191.781 84.0952 213.053 110.13 213.053C121.073 213.053 131.134 209.306 139.132 202.999V206.723C139.132 208.186 139.698 209.58 140.718 210.608L163.308 233.389C165.438 235.537 168.882 235.537 170.989 233.389L177.4 226.922C179.53 224.774 179.53 221.303 177.423 219.155ZM110.13 198.428C92.1088 198.428 77.5045 183.726 77.5045 165.527C77.5045 147.353 92.0838 132.625 110.13 132.625C128.15 132.625 142.755 147.328 142.755 165.527C142.755 183.701 128.175 198.428 110.13 198.428ZM110.134 143.594C100.895 143.594 93.4047 151.146 93.4047 160.465C93.4047 167.997 104.339 181.728 108.528 186.712C108.724 186.949 108.97 187.14 109.247 187.271C109.525 187.402 109.828 187.47 110.134 187.47C110.44 187.47 110.743 187.402 111.021 187.271C111.298 187.14 111.544 186.949 111.74 186.712C115.93 181.728 126.863 167.999 126.863 160.465C126.863 151.146 119.373 143.594 110.134 143.594ZM110.134 165.531C107.13 165.531 104.697 163.075 104.697 160.047C104.697 157.017 107.132 154.562 110.134 154.562C113.136 154.562 115.572 157.017 115.572 160.047C115.572 163.075 113.136 165.531 110.134 165.531Z" fill="black" fill-opacity="0.3"/>
</g>
<defs>
<filter id="filter0_d_2529_10863" x="1" y="38" width="247" height="289.598" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dx="4" dy="4"/>
<feGaussianBlur stdDeviation="3.5"/>
<feComposite in2="hardAlpha" operator="out"/>
<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.31 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2529_10863"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2529_10863" result="shape"/>
</filter>
<filter id="filter1_d_2529_10863" x="0" y="0" width="241" height="62" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="4"/>
<feGaussianBlur stdDeviation="2"/>
<feComposite in2="hardAlpha" operator="out"/>
<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_2529_10863"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_2529_10863" result="shape"/>
</filter>
<clipPath id="clip0_2529_10863">
<rect width="116" height="117" fill="white" transform="translate(63 118)"/>
</clipPath>
</defs>
</svg>
<p>Filter berdasarkan lokasi tempat tinggal Anda saat ini!</p> -->
<div>
 <img src={{ ('/img/lg3.png') }} class="fullscreen-img4">          
</div>
<div>
 <img src={{ ('/img/lg1.png') }} class="fullscreen-img">          
</div>
<div>
 <img src={{ ('/img/lg.png') }} class="fullscreen-img2">          
<div>
<div>
 <img src={{ ('/img/lg2.png') }} class="fullscreen-img3">          
<div>

    <div class="bg-[#E88A33]">
        <div
            class="container flex flex-col items-center justify-between p-6 mx-auto space-y-4 sm:space-y-0 sm:flex-row">

        </div>
    </div>
    </div>
     </div>
      </section>
</div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

    {{-- Responsive --}}
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

<style>
    .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            background-color: #135589;
            color: #fff;
            position: relative;
            z-index: 2;
        }

        .navbar-logo {
            margin-right: auto;
        }

        .navbar-logo img {
            height: 40px;
        }

        .navbar-inverse{
        background-color:  #135589;
        box-shadow:0px 5px 5px rgb(0, 0, 0, .55);
        /* position: relative; */
        z-index: 2;
    }
    </style>
