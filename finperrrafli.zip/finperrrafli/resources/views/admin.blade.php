@extends('partials.master')
@section('content')
    <nav>
        <div class="nav nav-tabs" id="nav-tab" role="tablist">
            <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button"
                role="tab" aria-controls="nav-home" aria-selected="true">Verifikasi Mitra</button>
            <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button"
                role="tab" aria-controls="nav-profile" aria-selected="false">Verifikasi Pembayaran</button>
        </div>
    </nav>
    <div class="tab-content" id="nav-tabContent">
        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
            <div class="container p-5">
                <div class="row mt-5">
                    <div class="col">
                        <div class="card">
                            <div class="card-body">
                                <div class="row p-3">
                                    <div class="col">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>ID Pembayaran</th>
                                                    <th>Username</th>
                                                    <th>Subtotal</th>
                                                    <th>Bukti Pembayaran</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
            <div class="container p-5">
                <div class="row mt-5">
                    <div class="col">
                        <div class="card">
                            <div class="card-body">
                                <div class="row p-3">
                                    <div class="col">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>ID Pembayaran</th>
                                                    <th>Username</th>
                                                    <th>Subtotal</th>
                                                    <th>Bukti Pembayaran</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($data as $item)
                                                <tr>
                                                    <td>{{ $item->transaksiID }}</td>
                                                    <td>{{ $item->pelangganID }}</td>
                                                    <td>{{ $item->totalPembayaran }}</td>
                                                    <td><a href="{{ asset('storage/'.$item->buktiPembayaran) }}">Buka File</a></td>
                                                    <td>
                                                        @if ($item->statusPembayaran == 0)
                                                        <a href="{{ route('terima.pembayaran',$item->transaksiID) }}" class="btn btn-primary">Terima</a> 
                                                        <a href="{{ route('tolak.pembayaran',$item->transaksiID) }}" class="btn btn-danger">Tolak</a></td>
                                                        @endif
                                                </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                            <div class="card">
                                <div class="card-body">
                                    Mohon selesaikan pembayaran anda sebelum tanggal 12 Februari 2023 23:59 WIB dengan rincian berikut
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            Transfer Bank
                                        </div>
                                        <div class="col text-end">
                                            BNI
                                        </div>
                                    </div>
                                    <hr>
                                    Nomor Rekening <br>
                                    800232335 <br>
                                    BNI PT. Findper (Pasar Senin)
                                    <div class="row">
                                        <div class="col text-end">
                                            <h5>Total Bayar</h5>
                                            <h5>Rp. 5.250.785</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <label for="">Upload Bukti Bayar</label>
                                    <input type="file" name="" id="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col">
                            <div class="d-flex justify-content-center">
                                <button class="btn btn-primary">Upload</button>
                                <div class="px-3"></div>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
