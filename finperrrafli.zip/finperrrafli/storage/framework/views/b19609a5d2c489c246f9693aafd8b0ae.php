<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Dashboard Mitra'); ?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter&family=Poppins:wght@500&display=swap" rel="stylesheet">

<div class="container-fluid">
    <div class="row justify-content-center" style="margin-left: 15%; margin-top: 10%">
    
        
        
                            
                            
        <div class="col-sm-6">
            <div class="card"
                style="width:315px; background-color:#135589; border-radius:20px;align-items: center;text-align:center; margin:100px; margin-top:150px; margin-left:70px">
                <div class="card-body">
                    <img src="<?php echo e(asset('img/icon-formulir-checklist.png')); ?>"
                        style="width:17%; margin-top: 15px;margin-bottom:15px">

                    <p class="card-title" style="color: white; font-size:20px"><b>Kontrak Anda</b></p>

                    <div class="card card-light"
                        style="height:50px; width:230px;  margin-top:15px; margin-bottom:15px; border-radius:60px">
                        <div class="row">
                            <div class="col-sm-2">
                                <img src="<?php echo e(asset('img/icon-pp-pelanggan.png')); ?>" style="width:50px; margin-bottom:5px"
                                    alt="Profile">
                            </div>
                            <div class="col-sm-10">
                                <h5 style="font-size:15px; font-color:rgb(1, 1, 1); margin-top:15px; margin-right:30px"><?php echo e($namaPelanggan); ?>budi gunadi
                                </h5>
                                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('partials.master(white_2)', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBPLLL\finperrrafli\resources\views/dashboard-mitra.blade.php ENDPATH**/ ?>