
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.css" rel="stylesheet" />

<?php $__env->startSection('title', 'Dashboard_Mitra(3)'); ?>

<?php $__env->startSection('content'); ?>

<h1>Dashboard Mitra</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout_3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBPLLL\finperrrafli\resources\views/dashboard_mitra.blade.php ENDPATH**/ ?>