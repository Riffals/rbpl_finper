

<?php $__env->startSection('title', 'index_edit_profil'); ?>


<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css' rel='stylesheet'>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>

<?php $__env->startSection('content'); ?>

<style>
    ::-webkit-scrollbar {
        width: 8px;
    }

    /* Track */
    ::-webkit-scrollbar-track {
        background: #f1f1f1;
    }

    /* Handle */
    ::-webkit-scrollbar-thumb {
        background: #888;
    }

    /* Handle on hover */
    ::-webkit-scrollbar-thumb:hover {
        background: #555;
    }

    .white-box {
        background-color: white;
        position: absolute;
        width: 1170px;
        height: 550px;
        left: 15%;
        top: 224px;

        border-radius: 20px;
    }

    .image_upload>input {
        display: none;
    }

    .form-control:focus {
        box-shadow: none;
        border-color: #BA68C8
    }

    .profile-button {
        background: #135589;
        box-shadow: none;
        border: none
    }

    .labels {
        font-size: 11px
    }

    .add-experience:hover {
        background: #BA68C8;
        color: #fff;
        cursor: pointer;
        border: solid 1px #BA68C8
    }
</style>

    
        <div class="white-box">
        <div class="row">
        <h4 align="center">Profil Anda</h4>
        <div class="col-md-6">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5" style="background-color: rgba(217, 217, 217, 0.5);" width="255px" left="384px" top="404px"><img class="rounded-circle mt-5" width="150px">
            <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td><img width="150px" src="<?php echo e(url('/data_file/'.$p->fotoprofil)); ?>"></td>    
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="p-3 py-5">
                <div class="mb-3">
                    <label for="nama" class="from-label">Nama: </label>
                    <br>
                    <td><?php echo e($p->nama_pelanggan); ?></td>
                </div>
                <div class="mb-3">
                    <label for="lokasi" class="from-label">Lokasi: </label>
                    <br>
                    <td><?php echo e($p->lokasi_pelanggan); ?></td>
                </div>
                <div class="mb-3">
                    <label for="nomorhp" class="from-label">Nomor HP: </label>
                    <br>
                    <td><?php echo e($p->nomorHP_pelanggan); ?></td>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="mt-5 text-center">
            <a href="/admin/pelanggan/profil/edit/<?php echo e($p->pelangganID); ?>" type="button" class="btn btn-primary profile-button">Edit Datadiri</a>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_guest_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBPLLL\finperrrafli\resources\views/indexeditprofil.blade.php ENDPATH**/ ?>