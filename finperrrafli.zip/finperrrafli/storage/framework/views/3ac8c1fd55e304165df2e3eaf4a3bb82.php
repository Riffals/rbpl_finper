<!DOCTYPE html>
<html lang="en">

<head>
    <title>Dashboard Admin</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter&family=Poppins:wght@500&display=swap" rel="stylesheet">

    <style>
        body {
            background-color: rgba(19, 85, 137, 0.42);
            font-family: 'Poppins', 'sans-serif';
            background-color: #8DA9BF;
            overflow-y: hidden;

        }

        .navbar {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #135589;
            color: #fff;
            box-shadow: 0px 4px 7px rgba(0, 0, 0, 0.47);
            width: 100%;
        }

        .navbar-logo {
            margin-right: auto;
        }

        .navbar-logo img {
            width: 30px
        }

        .navbar-icon {
            display: flex;
            align-items: center;
        }

        .navbar-icon-1 img {
            width: 20px;
            margin: 0 10px;
        }

        .navbar-icon-2 img {
            width: 35px;
            margin: 0 10px;
        }

        .btn-dark {
            background-color: #242424;
            font-color: white;
            margin-top: 50px;
            padding: 15px;
            border-radius: 20px 20px 0px 0px;
        }

        .jumbotron {
            background-color: #242424;
            border-radius: 0px 20px 0px 0px;
        }

        #terima-btn {
            background-color: white;
            color: #135589;
            border-radius: 100px;
            width: 80px;
            height: 40px;
        }

        #tolak-btn {
            background-color: #135589;
            color: white;
            border-radius: 100px;
            width: 80px;
            height: 40px;
            margin-left: 2px;
        }
    </style>
</head>

<body>
        <nav class="navbar">
            <div class="navbar-logo">
                <a href="#">
                    <img src="images/logo.png" alt="Logo">
                </a>
            </div>

            <div class="navbar-icon-2" data-toggle="dropdown" class="dropdown-toggle">
                <div class="container">
                    <span class="caret"></span></button>
                    <ul class="dropdown-menu" style="left: 77.6%; width:300px;">
                        <li class="dropdown-header">
                            <a href="#">
                                <img src="images/rectangle.png" alt="profil">
                            </a> Hi, Username
                        </li>
                        <li class="dropdown-header" style="color: Black; "> <a href="#">Mitra</a></li>
                        <li class="divider"></li>
                        <li class="dropdown-header" style="color: Black; "> <a href="#">Edit Profil</a></li>
                        <li class="dropdown-header" style="color: Black; font-weight: bold;"> <a href="/logout">Log
                                Out</a></li>
                    </ul>
                </div>
                <a href="123">
                    <img src="images/rectangle.png" alt="Profile">
                </a>
            </div>
        </nav>
        <div class="container">
            <div class="container" style="margin-left:0%">
                <div class="row">
                    <a href="http://127.0.0.1:8000/admin/dashmin" target="_self">
                        <button type="button" class="btn btn-dark">Verifikasi Mitra</button></a>
                    <a href="http://127.0.0.1:8000/admin/verbay" target="_self">
                        <button type="button" class="btn btn-dark">Verifikasi pembayaran</button></a>
                </div>
            </div>

            <div class="jumbotron">
                <table cellpadding="10" cellspacing="0"
                    style=" background-color: white;border-collapse: collapse;text-align:center; margin: 0 auto; font-weight: bold;">
                    <tr style="background-color: #E2E2E2; color: black; font-weight: bold;">
                        <td> Nama </td>
                        <td> Lokasi</td>
                        <td> Foto KTP </td>
                        <td> Foto SKCK </td>
                        <td> Gaji/jam </td>
                        <td style="border: none; background-color:#242424;"></td>
                    </tr>
                    <?php $__currentLoopData = $persetujuanMitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($v->nama_mitra); ?></td>
                            <td><?php echo e($v->lokasi_mitra); ?></td>
                            <td><img width="150px" src="<?php echo e(url('/data_file/'.$v->fotoktp)); ?>"></td>
                            <td><img width="150px" src="<?php echo e(url('/data_file/'.$v->fotoskck)); ?>"></td>
                            <td><?php echo e($v->gaji); ?></td>

                            <td style="border: none; background-color:#242424;">
                                <form action="dashmin/tolak/<?php echo e($v->verifikasiMitraID); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button id="tolak-btn" type="submit" data-toggle="modal" data-target="#tolakModal" class="btn btn-primary btn-sm">Tolak</button>
                                </form>
                            </td>


                        <tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\RBPLLL\finperrrafli\resources\views/dashmin.blade.php ENDPATH**/ ?>