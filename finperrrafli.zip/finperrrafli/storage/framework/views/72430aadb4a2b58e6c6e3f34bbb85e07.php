
<?php $__env->startSection('content'); ?>
    <nav>
        <div class="nav nav-tabs" id="nav-tab" role="tablist">
            <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button"
                role="tab" aria-controls="nav-home" aria-selected="true">List Mitra</button>
        </div>
    </nav>
    <div class="tab-content" id="nav-tabContent">
        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
            <div class="container p-5">
                <div class="row mt-5">
                    <div class="col">
                        <div class="card">
                            <div class="card-body">
                                <div class="row p-3">
                                    <div class="col">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Nama Mitra</th>
                                                    <th>Lokasi Mitra</th>
                                                    <th>Gaji</th>
                                                    <th>No HP</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                <tr>
                                                    <td><?php echo e($key+1); ?></td>
                                                    <td><?php echo e($item->nama_mitra); ?></td>
                                                    <td><?php echo e($item->lokasi_mitra); ?></td>
                                                    <td><?php echo e($item->gaji); ?></td>
                                                    <td><?php echo e($item->nomorHP_mitra); ?></td>
                                                    <td>
                                                        <a class="btn btn-success" href="<?php echo e(route('mitra.detail',$item->mitraID)); ?>">Detail</a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JC\JC24-Finper\resources\views/index.blade.php ENDPATH**/ ?>