<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Dashboard Pelanggan'); ?>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.5/flowbite.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter&family=Poppins:wght@500&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter&family=Poppins:wght@500&display=swap" rel="stylesheet">

<style>
    body {
        background-color: rgba(19, 85, 137, 0.42);
        font-family: 'Poppins', 'sans-serif';
        background-color: #8DA9BF;
        overflow-y: hidden;
    }

    .navbar {
        display: flex;
        align-items: center;
        padding: 10px;
        background-color: #135589;
        color: #fff;
        box-shadow: 0px 4px 7px rgba(0, 0, 0, 0.47);
        width: 100%;
    }

    .navbar-logo {
        margin-right: auto;
    }

    .navbar-logo img {
        width: 30px
    }

    .navbar-icon {
        display: flex;
        align-items: center;
    }


    .navbar-icon-2 img {
        width: 35px;
        margin: 0 10px;
    }

    .jumbotron {
        background-color: #ffffff;
        border-radius: 20px 20px 20px 20px;
        margin-top: 90px;
        margin-left: 10%;
        margin-right: 10%;
    }

    .profile-button {
        background: #135589;
        box-shadow: none;
        border: none
    }

    .card1 {
        background-color: #D9D9D9;
        border-radius: 20px;
    }
</style>

<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?> <br />
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<?php $__currentLoopData = $mitras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="jumbotron">
    <div class="form-group">
        <div class="container">
            <h1 class="h3" style="font-weight: bold; text-align:center">Data Diri</h1>
            <div class="row" style="margin-top:100px;">

                <div class="col-sm-5">
                    <div class="card1" href="#"
                        style="width:225px; height:300px; margin-left:100px; margin-top:-45px;">
                        <div class="form-group">
                            <div class="d-flex flex-column align-items-center text-center p-3 py-5"
                                style="background-color: rgba(217, 217, 217, 0.5);">
                                <img width="150px" src="<?php echo e(url('/data_file/' . $m->ppmitra)); ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-7">

                    <div class="form-group" style="margin-bottom:30px;">
                        <label for="nama">Nama:</label>
                        <td><?php echo e($m->nama_mitra); ?></td>
                    </div>

                    <div class="form-group" style="margin-bottom:30px;">
                        <label for="lokasi">Lokasi:</label>
                        <td><?php echo e($m->lokasi_mitra); ?></td>
                    </div>

                    <div class="form-group" style="margin-bottom:30px;">
                        <label for="nomorhp">Gaji:</label>
                        <td><?php echo e($m->gaji); ?></td>
                    </div>

                    <div class="form-group" style="margin-bottom:30px;">
                        <label for="email">Nomor HP:</label>
                        <td><?php echo e($m->nomorHP_mitra); ?></td>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <div class="container" style="align-items:center; justify-content:center; display:flex;">
        <button type="button" class="btn btn-dark profile-button"
            style="width: 200px; height: 50px; background-color: #135589; box-shadow: 0px 2px 8px #135589; border-radius: 16px;">
            <a href="/admin/mitra/datamitra/edit/<?php echo e($m->mitraID); ?>" class="h5"
                style="font-weight: bold; color: #ffffff; text-decoration:none;">Edit Data Diri</a>
        </button>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.master(white)', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RBPLLL\finperrrafli\resources\views/afterdatamitra.blade.php ENDPATH**/ ?>