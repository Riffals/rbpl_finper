
<?php $__env->startSection('content'); ?>
<div class="container-sm" style="width: 500px">
    <div class="card">
        <div class="card-body">
            <h2 class="text-center">Login</h2>
            <form action="<?php echo e(route('login.action')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Email address</label>
                    <input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="Email">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" id="exampleFormControlInput1" placeholder="Password">
                </div>
                <div class="mb-3">
                    <div class="d-flex justify-content-center">
                        <button class="btn btn-primary btn-lg">
                            Login
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JC\JC24-Finper\resources\views/login.blade.php ENDPATH**/ ?>