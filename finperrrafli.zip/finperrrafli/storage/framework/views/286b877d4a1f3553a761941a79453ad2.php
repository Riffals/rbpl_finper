<!DOCTYPE html>
<html lang="en">

<head>
    <title>Dashboard Admin</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter&family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter&family=Poppins:wght@500&display=swap" rel="stylesheet">

    <style>
        body {
            background-color: rgba(19, 85, 137, 0.42);
            font-family: 'Poppins', 'sans-serif';
            background-color: #8DA9BF;
            overflow-y: hidden;
        }

        .navbar {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: #135589;
            color: #fff;
            box-shadow: 0px 4px 7px rgba(0, 0, 0, 0.47);
            width: 100%;
        }

        .navbar-logo {
            margin-right: auto;
        }

        .navbar-logo img {
            width: 30px
        }

        .navbar-icon {
            display: flex;
            align-items: center;
        }


        .navbar-icon-2 img {
            width: 35px;
            margin: 0 10px;
        }

        .jumbotron {
            background-color: #ffffff;
            border-radius: 20px 20px 20px 20px;
            margin-top: 6%;
            margin-bottom: 10%;
            margin-left: 10%;
            margin-right: 10%;
        }

        .profile-button {
            background: #135589;
            box-shadow: none;
            border: none
        }

        .card1 {
            background-color: #D9D9D9;
            border-radius: 20px;
        }
    </style>

</head>

<form action="<?php echo e(url('admin/mitra/datamitra/store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <body>
        <nav class="navbar">
            <div class="navbar-logo">
                <a href="#">
                    <img src="<?php echo e(('/img/logo_finper.png')); ?>" alt="Logo">
                </a>
            </div>

            <div class="navbar-icon-2" data-toggle="dropdown" class="dropdown-toggle">
                <div class="container">
                    <span class="caret"></span></button>
                    <ul class="dropdown-menu" style="left: 77.6%; width:300px;">
                        <li class="dropdown-header">
                            <a href="#">
                                <img src="<?php echo e(('/img/icon-pp-mitra.png')); ?>" alt="profil">
                            </a> Hi, Username
                        </li>
                        <li class="dropdown-header" style="color: Black; "> <a href="#">Mitra</a></li>
                        <li class="divider"></li>
                        <li class="dropdown-header" style="color: Black; "> <a href="#">Edit Profil</a></li>
                        <li class="dropdown-header" style="color: Black; font-weight: bold;"> <a href="#">Log
                                Out</a></li>
                    </ul>
                </div>
                <a href="123">
                    <img src="<?php echo e(('/img/icon-pp-mitra.png')); ?>" alt="Profile">
                </a>
            </div>
        </nav>

        <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?> <br />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <?php endif; ?>

        <div class="jumbotron">
            <div class="form-group">
                <div class="container">
                    <h1 class="h3" style="font-weight: bold; text-align:center">Data Diri</h1>
                    <div class="row" style="margin-top:30px;">
                        <div class="col-sm-4">
                            <div class="card1" href="#" style="width:225px; height:300px; margin-left:100px; margin-top:-93px;">
                                <div class="form-group" style="margin-top: 50%;">
                                    <b style="margin-top: 50%;">File Gambar</b>
                                    <input type="file" name="ppmitra">
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-8">

                            <div class="row">
                                <div class="col-sm-6">

                                    <div class="form-group">
                                        <label">Nama:</label>
                                        <input
                                        style="width:300px; border-radius: 20px;"
                                            type="text" class="form-control" id="nama"
                                            placeholder="masukkan nama anda" name="nama">
                                        </input>
                                    </div>

                                    <div class="form-group">
                                        <label>Lokasi:</label>
                                        <input
                                        style="width:300px; border-radius: 20px;"
                                            type="text" class="form-control" placeholder="masukkan lokasi anda"
                                            id="lokasi" name="lokasi">
                                        </input>
                                    </div>

                                    <div class="form-group">
                                        <label>Gaji:</label>
                                        <input
                                        style="width:300px; border-radius: 20px;"
                                            type="integer" class="form-control" id="gaji"
                                            placeholder="masukkan nomor hp anda" name="gaji">
                                        </input>
                                    </div>

                                    <div class="form-group">
                                        <label>Nomor
                                            HP:</label>
                                        <input
                                        style="width:300px; border-radius: 20px;"
                                            type="integer" class="form-control" id="nohp"
                                            placeholder="masukkan nomor hp anda" name="nohp">
                                        </input>
                                    </div>
                                </div>

                                <div class="col-sm-3">


                                    <div class="form-group">
                                        <label>Upload
                                            KTP:</label>
                                        <input
                                        style="width:300px; border-radius: 20px;"
                                            type="file" class="form-control" id="fotoktp"
                                            placeholder="masukkan foto ktp anda" name="fotoktp">
                                        </input>
                                    </div>

                                    <div class="form-group">
                                        <label>Upload
                                            SKCK:</label>
                                        <input
                                            style="width:300px; border-radius: 20px;"
                                            type="file" class="form-control" id="fotoskck" name="fotoskck">
                                        </input>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container" style="align-items:center; justify-content:center; display:flex;">
                <button type="submit" class="btn btn-dark profile-button"
                    style="width: 200px; height: 50px; background-color: #135589; box-shadow: 0px 2px 8px #135589; border-radius: 16px; font-weight: bold; color: #ffffff; ">Submit</a>
                </button>
            </div>
        </div>
    </div>

    </body>
</form>
<?php /**PATH C:\xampp\htdocs\RBPLLL\finperrrafli\resources\views/isidatamitra.blade.php ENDPATH**/ ?>