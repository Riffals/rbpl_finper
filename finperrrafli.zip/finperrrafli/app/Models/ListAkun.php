<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class ListAkun extends Authenticatable
{
    use HasFactory;

    protected $table = 'listakuns';
    protected $primaryKey = 'listAkunID';

    // protected $table = 'listakun';

    protected $fillable = ['listAkunID', 'akunID', 'email', 'password'];
}
