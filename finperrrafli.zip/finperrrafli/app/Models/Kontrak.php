<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kontrak extends Model
{
    use HasFactory;

    protected $table = "kontraks";

    protected $guarded = [];

    // zara
    public function detailkontrak()
    {
    	return $this->hasOne('App\DetailKontrak');
    }

    public function transaksi()
    {
    	return $this->hasOne('App\Kontrak');
    }

    public function pelanggan()
    {
    	return $this->belongsTo('App\Pelanggan');
    }

    public function mitra()
    {
    	return $this->belongsTo('App\Mitra');
    }

}
