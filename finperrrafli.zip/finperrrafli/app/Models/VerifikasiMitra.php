<?php

namespace App\Models;

use App\Models\Mitra;
use Illuminate\Database\Eloquent\Model;

class VerifikasiMitra extends Model
{
    // public function mitra() {
    //     return $this->belongsTo(Mitra::class, '');
    // }
}
