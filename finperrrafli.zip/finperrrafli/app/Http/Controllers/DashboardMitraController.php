<?php

namespace App\Http\Controllers;

use App\Mitra;
use App\DetailKontrak;
use App\Models\Kontrak;
use App\Models\ListAkun;
use App\Models\Pelanggan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class DashboardMitraController extends Controller
{
    // public function showLamanDashboardMitra(Request $request){        
    //     // $mitraId = $request->input('mitraID');
    //     // $request->session()->put('mitraID', $mitraId);

    //     $mitraId = $request->session()->get('mitraID');
    //     $request->session()->put('mitraID', Auth::user()->akunID == '3');


    //     $namaPelanggan = ListAkun::join('akuns', 'akuns.akunID', '=', 'listakuns.akunID')
    //     ->join('mitras', 'mitras.mitraID', '=', 'listakuns.mitraID')
    //     ->join('kontrak', 'kontrak.pelangganID', '=', 'pelanggans.pelangganID')
    //         ->where('kontrak.mitraID', $mitraId)
    //         ->where('kontrak.statusKontrak', 1)
    //         ->pluck('pelanggans.nama_pelanggan')
    //         ->first();

    //     $jumlahTawaranKontrak = Kontrak::where('mitraID', $mitraId)
    //         ->where('statusKontrak', 0)
    //         ->count();
    //     // $jumlahTawaranKontrak = Kontrak::where('mitraID', 3)
    //     // ->count();

    //     return view('dashboard-mitra', ['namaPelanggan' => $namaPelanggan, 'jumlahTawaranKontrak' => $jumlahTawaranKontrak]);
    //     // return 123;
    // }

    public function showLamanDashboardMitra(Request $request)
{
    $listakunId = $request->input('listakunID');
    $listakunId = $request->session()->get('listakunID');
    // Ambil nilai 'listakunID' dari sesi

    $namaPelanggan = null;
    $jumlahTawaranKontrak = 0;

    if ($listakunId) {
        // Pastikan 'listakunID' ada dalam sesi
        $namaPelanggan = ListAkun::join('listakuns', 'listakuns.listakunID', '=', 'mitras.listakunID')
        ->join('mitras', 'mitras.mitraID', '=', 'kontrak.mitraID')
        ->join('kontrak', 'kontrak.pelangganID', '=', 'pelanggans.pelangganID')
            ->where('kontrak.statusKontrak', 1)
            ->pluck('pelanggans.nama_pelanggan')
            ->first();

        $jumlahTawaranKontrak = Kontrak::where('mitraID', 0)
            ->where('statusKontrak', 0)
            ->count();
    }

    return view('dashboard-mitra', ['namaPelanggan' => $namaPelanggan, 'jumlahTawaranKontrak' => $jumlahTawaranKontrak]);
}

    

    public function showForm(){
        return view('form');
    }

}
