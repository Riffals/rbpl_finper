<?php

namespace App\Http\Controllers;

use App\Models\Pelanggan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

// use Auth;

class ProfilController extends Controller
{
    /**
     * Show the update profile page.
     *
     * @param  Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index() //nama metodd bebas
    {
    	return view('indexprofil');
    }

    public function buat()
    {
    	return view('buatprofil');
    }
    public function store(Request $request)
    {
        // insert data ke table pegawai
        DB::table('pelanggans')->insert([
            'pelangganID' => $request->id,
            'nama_pelanggan' => $request->nama,
            'lokasi_pelanggan' => $request->lokasi,
            'nomorHP_pelanggan' => $request->nomorhp
        ]);
        // alihkan halaman ke halaman pegawai
        return redirect('/admin/pelanggan/profilpelanggan');

    }
    public function uploading(){
		$pelanggan = Pelanggan::get();
		return view('buatprofil',['pelanggan' => $pelanggan]);
	}
        // untuk create, paksa isi akunID = 2
    public function proses_uploading(Request $request){
    $this->validate($request, [
        'fotoprofil' => 'required|file|image|mimes:jpeg,png,jpg|max:2048',
        
    ]);

    // menyimpan data file yang diupload ke variabel $file
    $fotoprofil = $request->file('fotoprofil');

    $nama_file = time()."_".$fotoprofil->getClientOriginalName();

    // isi dengan nama folder tempat kemana file diupload
    $tujuan_upload = 'data_file';
    $fotoprofil->move($tujuan_upload,$nama_file);

    Pelanggan::create([
        'akunID' => 2,
        'nama_pelanggan' => $request->nama,
        'lokasi_pelanggan' => $request->lokasi,
        'nomorHP_pelanggan' => $request->nomorhp,
        'fotoprofil' => $nama_file
        
    ]);

    return redirect('/admin/pelanggan/profilpelanggan');
	}

    // ambil data untuk progil sekrang
    public function indexedit() //nama metodd bebas
    {
        $pelanggan = DB::table('pelanggans')->get();
        return view('indexeditprofil',['pelanggan' => $pelanggan]);
    }

    public function edit($id) {
        // mengambil data pegawai berdasarkan id yang dipilih
        $pelanggan = DB::table('pelanggans')->where('pelangganID',$id)->get();
        // passing data pegawai yang didapat ke view edit.blade.php
        return view('editprofil',['pelanggan' => $pelanggan]);
    }

    public function update(Request $request) {
        // update data pegawai
        DB::table('pelanggans')->where('pelangganID',$request->id)->update([
            'pelangganID' => $request->id,
            'nama_pelanggan' => $request->nama,
            'lokasi_pelanggan' => $request->lokasi,
            'nomorHP_pelanggan' => $request->nomorhp
        ]);
        // alihkan halaman ke halaman pegawai
        return redirect('/admin/pelanggan/profilpelanggan');
    }

    // public function indexmitra() 
    // {
    //     return view('dashmin');
    // }
}