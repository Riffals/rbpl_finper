<?php

namespace App\Http\Controllers;

use App\Models\Kontrak;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Request as HttpRequest;


class TawaranKontrakController extends Controller
{
    public function showLamanTawaranKontrak(Request $request){

        $mitraId = $request->session()->get('mitraID');

        $tawaranKontrak = Kontrak::join('detail_kontraks', 'kontraks.kontrakID', '=', 'detail_kontraks.kontrakID')
            ->join('pelanggans', 'kontraks.pelangganID', '=', 'pelanggans.pelangganID')
            ->join('transaksis', 'kontraks.kontrakID', '=', 'transaksis.kontrakID')
            ->where('kontraks.mitraID', $mitraId)
            ->where('kontraks.statusKontrak', 0)
            ->select(
                'pelanggans.nama_pelanggan',
                'pelanggans.lokasi_pelanggan',
                'detail_kontraks.jamKerja',
                'detail_kontraks.hariKerja',
                'transaksis.totalPembayaran'
            )
            ->get();

        return view('tawaran-kontrak', ['tawaranKontrak' => $tawaranKontrak]);
    }

    public function tolak($id){
        //menghapus data pegawai berdasarkan id
        Kontrak::where('kontrakID', $id)->delete();
        //alihkan halaman ke halaman pegawai
        return redirect('/tawaran-kontrak');
    }

}
