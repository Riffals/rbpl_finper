<?php

namespace App\Http\Controllers;

use App\Models\Mitra;

use App\Models\Transaksi;
use Illuminate\Http\Request;
use App\Models\VerifikasiMitra;
use Illuminate\Support\Facades\DB;
use App\Models\VerifikasiPembayaran;


class DashminController extends Controller
{
    public function showlamandashmin (){
        $persetujuanMitra = Mitra::join ('verifikasi_mitras', 'mitras.mitraID', '=' , 'verifikasi_mitras.mitraID')
        -> where('persetujuan_mitra', '0')->get();

	// mengirim data pegawai ke view pegawai
	return view('dashmin', ['persetujuanMitra'=>$persetujuanMitra]);
        //return view ('/dashmin');
    }


    public function showlamanverbay (){
        $persetujuanBayar = Transaksi::join('verifikasi_pembayarans', 'transaksis.transaksiID', '=', 'verifikasi_pembayarans.transaksiID')
        ->join('kontraks', 'kontraks.kontrakID', '=', 'transaksis.kontrakID')
        ->join('pelanggans', 'pelanggans.pelangganID', '=', 'kontraks.pelangganID')
        ->where('persetujuan_pembayaran', '0')
        ->get();

        return view('verbay', ['persetujuanBayar'=>$persetujuanBayar]);
        //return view ('/dashmin');
    }


    public function tolak($id)
{
    // Menghapus data pegawai berdasarkan id yang dipilih
    VerifikasiMitra::where('verifikasiMitraID', $id)->delete();

    // Alihkan halaman ke halaman karyawan
    return redirect('/admin/dashmin');
}

public function hapus($id)
{
    // Menghapus data pegawai berdasarkan id yang dipilih
    VerifikasiPembayaran::where('verifikasiPembayaranID', $id)->delete();

    // Alihkan halaman ke halaman karyawan
    return redirect('/admin/verbay');
}

public function setuju($id)
{
    $mitra = VerifikasiMitra::findOrFail($id);
    $mitra->verifikasiMitraID = 1;
    $mitra->save();

    return redirect()->back();
}


}
